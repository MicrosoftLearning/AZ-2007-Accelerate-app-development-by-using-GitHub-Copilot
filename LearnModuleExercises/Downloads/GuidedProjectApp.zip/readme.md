This folder contains the sample apps for the Guided Project module.
