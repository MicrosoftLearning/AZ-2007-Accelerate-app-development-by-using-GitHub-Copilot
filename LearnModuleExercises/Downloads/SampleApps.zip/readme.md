This folder contains sample apps that are used in the APL2007 training. Many of the exercise units use these sample apps as the starting point for coding projects.
