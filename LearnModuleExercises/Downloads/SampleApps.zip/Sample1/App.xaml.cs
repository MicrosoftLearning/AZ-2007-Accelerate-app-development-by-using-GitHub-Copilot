﻿using System.Windows;

namespace ParallelAsyncExample
{
    public partial class App : Application
    {
    }
}
